'''
demo演示
'''
import cv2
import numpy as np
from mmdet.apis import inference_detector, init_detector, show_result_pyplot
import torch
import mmcv

class RoadSeg:
    def __init__(self, config_path ,model_path):
        '''
        @param model_path: 模型路径
        @param config_path: 配置文件路径
        '''
        self.config_path = config_path
        self.model_path = model_path
        self.device = 'cuda:0' if torch.cuda.is_available() else 'cpu' #优先使用 GPU（cuda:0），如果没有 GPU 则使用 CPU。
        
        # 加载模型
        self.model = init_detector(self.config_path, self.model_path, device=self.device)
        # 参数        
        self.CLASSES = ('arrow', 'car', 'dashed', 'line')
        self.colors  = [(255,0,255), (0,255,255), (0,255,0), (0,0,255)]
        self.alpha_list = [0.3, 0.5, 0.3, 0.3]
    
    def convertResult(self, result):
        '''
        @param result: 检测结果
        @return: bboxes, labels, segms 结果
        '''
        bbox_result, segm_result = result # 输出 边框列表，每个类别一个（Ni,5）的二维数组。每个类别一个包含 N_i 个布尔数组的列表，每个布尔数组是一个 mask
        # 将结果转换为numpy数组
        bboxes = np.vstack(bbox_result)#把所有类别的边框堆叠成一个大数组 [N_total, 5]；每行是一个目标的 [x1, y1, x2, y2, score]。
        # 制作标签id
        labels = [
            np.full(bbox.shape[0], i, dtype=np.int32)
            for i, bbox in enumerate(bbox_result)
        ]


        # 举例
        # labels = [
        # np.full(2, 0),   # 对应类别0的两个目标，label 都是 0
        # np.full(1, 1),   # 类别1的1个目标，label 是 1
        # np.full(0, 2),   # 类别2没目标
        # np.full(3, 3)    # 类别3的3个目标


        labels = np.concatenate(labels)          # labels = [0, 0, 1, 3, 3, 3]  # 每个目标的 label 对应其所属类别
        # 制作分割mask
        segms = mmcv.concat_list(segm_result) # 把二维列表拼成一个一维列表
        segms = np.stack(segms, axis=0)  # # 叠成一个三维数组：shape = (N, H, W)

        return bboxes, labels, segms

    def inference(self, video_path,threshold=0.3):
        '''
        @param video_path: 视频路径
        '''
        cap = cv2.VideoCapture(video_path)
        # videoWriter保存为mp4视频
        fourcc = cv2.VideoWriter_fourcc(*'mp4v') # 指定输出视频的编码格式为 'mp4v'
        # 帧率
        fps = cap.get(cv2.CAP_PROP_FPS)
        # 分辨率
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        # 创建视频写入对象
        # 获取视频文件名
        video_name = video_path.split('/')[-1].split('.')[0]
        # 拼接
        record_video_path = './record_video/' + video_name + '.mp4'  # 将处理后的视频保存到 ./record_video/ 文件夹下，命名为同名 mp4 文件
        videoWriter = cv2.VideoWriter(record_video_path, fourcc, fps, (width, height))
        

        while True:
            ret, frame = cap.read()
            # 缩放为一半

            if not ret:
                break
            result = inference_detector(self.model, frame)
            bboxes, labels, segms = self.convertResult(result)
          
            # 遍历每一个检测结果
            for i,box in enumerate(bboxes):
                # 如果检测结果的置信度大于阈值
                conf =  box[-1]
                if conf > threshold:
                    # 检测到的框
                    l,t,r,b = box[:4].astype('int')
                    # 对应mask
                    seg = segms[i]  # 掩膜的就是一个和图像一样大小的二维数组，用布尔值表示
                    # 若mask为true，则将frame中的像素置为半透明
                    alpha = self.alpha_list[labels[i]]
                    color = self.colors[labels[i]]
                    frame[seg > 0,0] = frame[seg > 0,0] * alpha + color[0] * (1-alpha)  # 红色通道变红
                    frame[seg > 0,1] = frame[seg > 0,1] * alpha + color[1] * (1-alpha)  # 绿色通道变绿
                    frame[seg > 0,2] = frame[seg > 0,2] * alpha + color[2] * (1-alpha)  # 蓝色通道变蓝

                    # seg 是一张和图像同样大小的二维“掩膜”数组，比如：seg.shape = (720, 1280)
                    # frame[seg > 0, 0]等价于：取出图像中 所有位置满足 seg > 0 的像素点的红色通道值
                    # seg > 0 是一个二维布尔索引，选中的是像素位置（height, width）
                    # ,0 表示只取红色通道（channel 0）

              
                    # 绘制检测框
                    # cv2.rectangle(frame,(l,t),(r,b),(0,255,0),2)
                    # 绘制类别
                    # cv2.putText(frame,str(self.CLASSES[labels[i]]),(l,t-10),cv2.FONT_HERSHEY_SIMPLEX,1,(255,0,255),2)
           
            # 写入视频
            videoWriter.write(frame)  # 将处理后的视频帧写入到输出视频中。
            # 显示结果
            # resize
            frame = cv2.resize(frame, (int(width/2), int(height/2)))
            cv2.imshow('result',frame)
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break
        cap.release()
        videoWriter.release()
        cv2.destroyAllWindows()


if __name__ == '__main__':
    # 实例化
    road_seg = RoadSeg( './weights/tiny.py' , './weights/tiny.pth')
    # 视频路径
    video_path = 'imgs/lane.MOV'
    # 检测结果
    road_seg.inference(video_path)

